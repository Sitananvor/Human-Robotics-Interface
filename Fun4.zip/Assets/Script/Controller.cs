using UnityEngine;
using UnityEngine.UI;
using M2MqttUnity;
using System.Collections.Generic;

public class Controller : MonoBehaviour
{
    [Header("MQTT Client")]
    public M2MqttUnityClient mqttClient;

    [Header("Proximity Sensors")]
    public GameObject proximitySensor0;
    public GameObject proximitySensor1;
    public GameObject proximitySensor2;

    [Header("Proximity Visual Settings")]
    public Color proximityActiveColor = Color.green;
    public Color proximityInactiveColor = Color.black;

    [Header("Color Display")]
    public GameObject colorDisplayObject;

    [Header("Actuator Control Buttons")]
    public Button actuator0ExtendButton;
    public Button actuator0RetractButton;
    public Button actuator1ExtendButton;
    public Button actuator1RetractButton;
    public Button actuator2ExtendButton;
    public Button actuator2RetractButton;

    // Internal state
    private Dictionary<int, GameObject> sensorObjects = new Dictionary<int, GameObject>();
    private Dictionary<int, Renderer> sensorRenderers = new Dictionary<int, Renderer>();
    private Dictionary<int, int> lastProximityValues = new Dictionary<int, int>();
    private Renderer colorRenderer;
    private string lastColor = "NONE";

    void Start()
    {
        // Get MQTT client and subscribe to sensor updates
        if (mqttClient == null) mqttClient = FindObjectOfType<M2MqttUnityClient>();
        mqttClient.OnSensorUpdate += HandleSensorUpdate;

        // Map proximity sensor objects
        sensorObjects[0] = proximitySensor0;
        sensorObjects[1] = proximitySensor1;
        sensorObjects[2] = proximitySensor2;

        // Cache renderer and set default inactive color
        foreach (var kvp in sensorObjects)
        {
            if (kvp.Value != null)
            {
                Renderer rend = kvp.Value.GetComponent<Renderer>();
                if (rend != null)
                {
                    sensorRenderers[kvp.Key] = rend;
                    rend.material.color = proximityInactiveColor;
                }
            }
        }

        // Get renderer for color display object
        if (colorDisplayObject != null)
            colorRenderer = colorDisplayObject.GetComponent<Renderer>();

        // Bind UI buttons to actuator commands
        actuator0ExtendButton?.onClick.AddListener(() => OnExtend(0));
        actuator0RetractButton?.onClick.AddListener(() => OnRetract(0));
        actuator1ExtendButton?.onClick.AddListener(() => OnExtend(1));
        actuator1RetractButton?.onClick.AddListener(() => OnRetract(1));
        actuator2ExtendButton?.onClick.AddListener(() => OnExtend(2));
        actuator2RetractButton?.onClick.AddListener(() => OnRetract(2));
    }

    void OnDestroy()
    {
        if (mqttClient != null) mqttClient.OnSensorUpdate -= HandleSensorUpdate;
    }

    // Handle incoming sensor data and route to correct handler
    private void HandleSensorUpdate(TeleSortingSensorData data)
    {
        switch (data.id)
        {
            // Proximity sensors (ID 0-2)
            case 0:
            case 1:
            case 2:
                UpdateProximitySensor(data.id, data.GetProximityValue());
                break;
            // Color sensor (ID 10)
            case 10:
                UpdateColorDisplay(data.GetColorValue());
                break;
        }
    }

    // Update proximity sensor color based on detection value
    private void UpdateProximitySensor(int sensorID, int value)
    {
        if (!sensorObjects.ContainsKey(sensorID)) return;
        if (lastProximityValues.ContainsKey(sensorID) && lastProximityValues[sensorID] == value) return;

        lastProximityValues[sensorID] = value;
        bool isActive = (value == 1);

        if (sensorRenderers.ContainsKey(sensorID) && sensorRenderers[sensorID] != null)
            sensorRenderers[sensorID].material.color = isActive ? proximityActiveColor : proximityInactiveColor;
    }

    // Convert color name from sensor into a Unity Color
    private void UpdateColorDisplay(string colorName)
    {
        if (colorRenderer == null || lastColor == colorName) return;

        lastColor = colorName;

        Color displayColor = colorName.ToUpper() switch
        {
            "RED" => Color.red,
            "YELLOW" => Color.yellow,
            "GREEN" => Color.green,
            "CYAN" => Color.cyan,
            "PURPLE" => new Color(0.5f, 0f, 0.5f),
            _ => Color.white
        };

        colorRenderer.material.color = displayColor;
    }

    // Send command to extend the actuator
    private void OnExtend(int actuatorID)
    {
        mqttClient.ExtendActuator(actuatorID);
    }

    // Send command to retract the actuator
    private void OnRetract(int actuatorID)
    {
        mqttClient.RetractActuator(actuatorID);
    }
}