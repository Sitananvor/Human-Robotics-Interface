using UnityEngine;

public class GameController : MonoBehaviour
{
    [Header("Setting")]
    public GameObject targetObject;
    public float moveSpeed = 10f;

    private int direction = 1;
    private bool isMoving = false;

    private GameObject spawnedObject;

    // Function
    public void Show()
    {
        if (targetObject != null)
        {
            targetObject.SetActive(true);
            isMoving = false;
        }
    }

    public void Hide()
    {
        if (targetObject != null)
        {
            targetObject.SetActive(false);
            isMoving = false;
        }
    }

    public void Spawn()
    {
        if (targetObject != null && spawnedObject == null)
        {
            spawnedObject = Instantiate(targetObject, new Vector3(-150, 0, 100), Quaternion.Euler(0, -42, 0));
            spawnedObject.name = "SpawnObject";
            spawnedObject.SetActive(true);
        }
    }

    public void Destory()
    {
        if (spawnedObject != null)
        {
            Destroy(spawnedObject);
        }
    }

    public void Move()
    {
        if (targetObject != null)
        {
            isMoving = true;
        }
    }
    
    void Update()
    {
        if (isMoving && targetObject != null && targetObject.activeSelf)
        {
            if (targetObject.transform.position.x >= 20f) direction = -1;
            else if (targetObject.transform.position.x <= -30f) direction = 1;

            targetObject.transform.position += new Vector3(direction, 0, 0) * moveSpeed * Time.deltaTime;
        }
    }
}